#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
Abdullah Enes Dizer / 150119880
Yagmur Kocoglu / 150119715
Mevlut Eren Topal / 150117025
*/
typedef struct operation_type {
    char optname[100];
    float commission;
    int optnum;
    struct operation_type* nextopt;
}operation_type;

typedef struct transaction{
    int optype;
    int tno;
    float amount;
    struct transaction* nexttr;
}transacation;

typedef struct customer {
    char fname[100];
    char lname[100];
    int cno;
    float paid_commission;
    transacation* trans;
    struct customer* nextc;
}customer;

typedef struct branch {
    char bname[100];
    int bno;
    customer* custs;
    struct branch* nextb;
}branch;

typedef struct bank {
    branch* branches;
    operation_type* optypes;
}bank;

//reads operation type txt
//linked every operation types
void readOperation_type(operation_type** p){
    int countL = 1; //count for txt line
    char chr;
    char fileName[100];
    int i;
    printf("Please enter the name of the input file : \n");
    scanf("%s", fileName);
	printf("\n");
    FILE *ptr;
    ptr = fopen(fileName, "r"); //open file

    //get line number of txt
    for(chr = getc(ptr); chr!=EOF; chr = getc(ptr)){
        if(chr=='\n'){
            countL =countL+1;
        }
        }
    //linked operation types using linked list
    ptr = fopen(fileName, "r");
    for (i = 1; i <= countL ; i++) {
        char optname[100];
        float commission ;
        fscanf(ptr, "%s %f\n", optname, &commission);
        

        operation_type* new_opt = malloc(sizeof(operation_type));
        operation_type *l = *p;
        new_opt->optnum = i;
        strcpy(new_opt->optname,optname);
        new_opt->commission = commission;
        new_opt->nextopt = NULL;

        if (*p == NULL) {
            *p = new_opt;
        }
        else {
            while (l->nextopt != NULL)
                l = l->nextopt;

            l->nextopt = new_opt;
        }
    }
}
//prints every operation types
void printOperationTypes(operation_type *p){
    operation_type *temp =p;
    printf("optypes linked list : \n");
    while (temp != NULL)
    {
        printf("--%d %s %.2f \n", temp->optnum, temp->optname, temp->commission);
        temp = temp->nextopt;
    }
}
//reads branches txt
//linked every branches
void readBranches(branch** b){

    int countL = 1;//count for txt line
    char chr;
    char fileName[100] ;
    int i;
    printf("Please enter the name of the input file : \n");

    scanf("%s", fileName);

    FILE *ptr;
    ptr = fopen(fileName, "r"); //open txt

    //count line from txt
    for(chr = getc(ptr); chr!=EOF; chr = getc(ptr)){
        if(chr=='\n'){
            countL =countL+1;
        }
    }
    //linked branches using linked list
    ptr = fopen(fileName, "r");
    for (i = 1; i <= countL ; i++) {
        char branchname[100];

        fscanf(ptr, "%s\n", branchname);
        branch* new_branch = malloc(sizeof(branch));
        branch *l = *b;
        new_branch->bno = i;
        strcpy(new_branch->bname,branchname);
        new_branch->custs = NULL;//head
        new_branch->nextb = NULL;

        if (*b == NULL) {
            *b = new_branch;
        } else {
            while (l->nextb != NULL)
                l = l->nextb;

            l->nextb = new_branch;
        }
    }

}
//prints every branches
void printBranches(branch *b){
    branch *temp =b;
    while (temp != NULL)
    {
        printf("Branch : %d %s\n", temp->bno, temp->bname);
        temp = temp->nextb;
    }
}
//reads customer txt
//linked every customer in which branch
void readCustomers(branch** b){

    int countL = 1; // line counter
    char chr;
    char fileName[100];
    int i;
    printf("Please enter the name of the input file : \n");
    scanf("%s", fileName);

    FILE *ptr;
    ptr = fopen(fileName, "r");

    //count line number from txt
    for(chr = getc(ptr); chr!=EOF; chr = getc(ptr)){
        if(chr=='\n'){
            countL =countL+1;
        }
    }
    //linked customer in which branches using linked list
    ptr = fopen(fileName, "r");
    for (i = 1; i <= countL ; i++) {
        int cusNo = 1;
        char customername[100];
        char customerlast[100];
        int branchNo;

        branch *br = *b;
        fscanf(ptr, "%d %s %s\n",&branchNo ,customername,customerlast);
        while (br->bno != branchNo){
            br = br->nextb;
        }

        customer* new_customer = malloc(sizeof(customer));
        customer *l =  br->custs;
        strcpy(new_customer->fname,customername);
        strcpy(new_customer->lname,customerlast);
        new_customer->trans = NULL;//head
        new_customer->nextc = NULL;

        if (br->custs == NULL) {
            new_customer->cno = cusNo;
            br->custs = new_customer;
        }

        else {
            while (l->nextc != NULL){
                cusNo++;
                l = l->nextc;
            }
            cusNo++;
            new_customer->cno = cusNo;
            l->nextc = new_customer;

        }
    }
}
//prints every customer with branches
void printCustomers(branch *b){
    branch *temp = b;
    printf("**********************************\n");
    while (temp != NULL)
    {
        printf("Branch : %d %s\n", temp->bno, temp->bname);

        customer *temp1 = temp->custs;
        while(temp1 != NULL){
            printf("--%d %s %s\n",temp1->cno,temp1->fname,temp1->lname);
            temp1 = temp1->nextc;
        }
        temp = temp->nextb;
    }
}
//read transactions txt
//linked every transaction in which customer and branch
void readTransactions(branch** b){
    int countL = 1; //count line number
    char chr;
    char fileName[100];
    int i;
    printf("Please enter the name of the input file : \n");
    scanf("%s", fileName);

    FILE *ptr;
    ptr = fopen(fileName, "r");

    //count line number from txt
    for(chr = getc(ptr); chr!=EOF; chr = getc(ptr)){
        if(chr=='\n'){
            countL =countL+1;
        }
    }
    //linked every transaction in which customer and branches
    ptr = fopen(fileName, "r");
    for (i = 1; i <= countL ; i++) {
        int tNo = 1;
        int branchNo;
        int cid;
        int opty;
        float amount;

        branch *br = *b;


        fscanf(ptr, "%d %d %d %f\n",&branchNo ,&cid,&opty,&amount);
        //transaction's branch number go to whichever branch it is.
        while (br->bno != branchNo){
            br = br->nextb;
        }
        customer *temp = br->custs;//temporary
        //transaction's customer id go to whichever customer it is.
        while (temp->cno != cid){
            temp = temp->nextc;
        }


        transacation * new_trans = malloc(sizeof(transacation));
        transacation *l =  temp->trans;
        new_trans->optype = opty;
        new_trans->amount =amount;
        new_trans->nexttr = NULL;


        if (temp->trans == NULL) {
            new_trans->tno = tNo;
            temp->trans = new_trans;
        }

        else {
            while (l->nexttr != NULL){
                tNo++;
                l = l->nexttr;
            }
            tNo++;
            new_trans->tno = tNo;
            l->nexttr = new_trans;
        }
    }
}
//prints every transaction with branches and customer
void printTransactions(branch *b){
    branch *temp =b;
    printf("**********************************\n");
    while (temp != NULL)
    {
        printf("Branch : %d %s\n", temp->bno, temp->bname);
        customer *temp1 = temp->custs;
        while(temp1 != NULL){
            printf("--%d %s %s\n",temp1->cno,temp1->fname,temp1->lname);
            transacation *temp2 = temp1->trans;
            while (temp2 !=NULL){
                printf("        ++tno %d operation type (optype) %d amount %.2f\n",temp2->tno,temp2->optype,temp2->amount);
                temp2 = temp2->nexttr;
            }
            temp1 = temp1->nextc;
        }
        temp = temp->nextb;
    }

}
//prints paid commission
void printPaidCommission(branch *b, operation_type *p){
    branch *temp =b;

    printf("**********************************\n");
    while (temp != NULL)
    {
        printf("Branch : %d %s\n", temp->bno, temp->bname);
        customer *temp1 = temp->custs;
        while(temp1 != NULL){
            printf("--> cust id %d : %s %s\n",temp1->cno,temp1->fname,temp1->lname);
            transacation *temp2 = temp1->trans;
            while (temp2 !=NULL){
                operation_type *temp3 =p;
                while(temp3->optnum != temp2->optype){
                    temp3 = temp3->nextopt;
                }
                float com = (temp2->amount / 100) * temp3->commission;
                temp1->paid_commission += com; //add customer's paid commission number
                printf("        --tno %d operation type %d commission rate %.2f amount %.2f paid commission %.2f total commission %.2f\n",
                       temp2->tno,temp2->optype,temp3->commission,temp2->amount,com,temp1->paid_commission);
                temp2 = temp2->nexttr;
            }
            if(temp1->paid_commission == 0){
                printf("--(customer has no transaction)\n");
            }
            printf("** paid commission %.2f\n",temp1->paid_commission);
            printf("\n");
            temp1 = temp1->nextc;
        }
        temp = temp->nextb;
    }

}
int main(){

    bank* bank1 ; //bank
    bank1 = (struct bank*)malloc(sizeof(struct bank));
    bank1->optypes = NULL;//head
    bank1->branches = NULL;//head


    int option;

    while (1) {

        printf("\n");
        printf("1) Read operation types from the file\n");
        printf("2) Read branches from the file\n");
        printf("3) Read customers from the file\n");
        printf("4) Read customer transactions from the file\n");
        printf("5) Calculate paid commission amount of each customers in each branches\n");
        printf("\n");
        printf("Option :");
        scanf("%d",&option);
        if(option==1){
            readOperation_type(&( bank1->optypes));
            printOperationTypes( bank1->optypes);

        }

        else if(option==2){
            readBranches(&(bank1->branches));
            printBranches(bank1->branches);

        }
        else if(option==3){
            readCustomers(&(bank1->branches));
            printCustomers(bank1->branches);

        }
        else if(option==4){
            readTransactions(&(bank1->branches));

            printTransactions(bank1->branches);

        }
        else if(option==5){

            printPaidCommission(bank1->branches,bank1->optypes);

        }
        else {
            break;
        }


    }
    return 0;


}

